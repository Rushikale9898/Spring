package com.springPractice;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestContainer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new AnnotationConfigApplicationContext(ProductConfig.class);

		// create Object product
		Product product = (Product) context.getBean("product");

		product.setproductId(246);
		product.setproductName("Samsung S23");
		product.setproductPrice(89000);

		System.out.println(product.toString());

	}

}
