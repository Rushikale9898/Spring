package com.usingXml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestContainer1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");

		// Product product = new Product();
		Product product = (Product) context.getBean("Product");

		System.out.println(product.toString());
		
		

	}

}
