package com.firstSpring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestContainer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 ApplicationContext context=new ClassPathXmlApplicationContext("config.xml");
         
         
         Employee employee= (Employee)context.getBean("Employee");
         System.out.println(employee.toString());
	}
	
}