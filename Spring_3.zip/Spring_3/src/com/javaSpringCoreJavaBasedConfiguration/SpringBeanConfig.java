package com.javaSpringCoreJavaBasedConfiguration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringBeanConfig {
	
	@Bean(name="Patient1")
	public Patient getPatientBean()
	{
		return new Patient();
	}

}
