package com.javaSpringCoreJavaBasedConfiguration;

public class Patient {

	private int PatientId;
	private String PatientName;
	private String PatientAddress;
	
	
	public Patient(int patientId, String patientName, String patientAddress) {
		super();
		PatientId = patientId;
		PatientName = patientName;
		PatientAddress = patientAddress;
		
	}


	public Patient() {
		
	}



	public void setPatientId(int patientId) {
		this.PatientId = patientId;
	}


	public void setPatientName(String patientName) {
		this.PatientName = patientName;
	}


	public void setPatientAddress(String patientAddress) {
		this.PatientAddress = patientAddress;
	}


	@Override
	public String toString() {
		return "Patient [PatientId=" + PatientId + ", PatientName=" + PatientName + ", PatientAddress=" + PatientAddress
				+ "]";
	}
	
	
}