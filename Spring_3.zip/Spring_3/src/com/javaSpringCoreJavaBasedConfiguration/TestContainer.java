package com.javaSpringCoreJavaBasedConfiguration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class TestContainer {

	public static void main(String[] args) {
		
		ApplicationContext context =new AnnotationConfigApplicationContext(SpringBeanConfig.class);
		
		Patient patient=(Patient)context.getBean("Patient1");
		
		patient.setPatientId(144);
		patient.setPatientName("jemmy");
		patient.setPatientAddress("Landon");
		
		System.out.println(patient.toString());

	}

}
