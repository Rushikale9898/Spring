package springBeanCollaborationJavaBasedConfiguaration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringContainerClass {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringBeansConfiguaration.class);

		Department department = (Department)context.getBean("department1");
		department.setDepartmentId(8989);
		department.setDepartmentName("QA");
		
		System.out.println(department.toString());
		
		Employee employee = (Employee)context.getBean("employee1");
		employee.setEmployeeId(1010);
		employee.setEmployeeName("Rajesh");
		employee.setEmployeeRole("Web Developer");
		employee.setEmployeeSalary(89890.56);
		
		employee.setDepartment(department);
		
		System.out.println(employee.toString());	
		

	}
	

}
